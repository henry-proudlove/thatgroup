<div class="my_meta_control">
	<?php $mb->the_field('location'); ?>
		<div>
			<h4>Project Town</h4>
			<input type="text" name="<?php $mb->the_name(); ?>" value="<?php $mb->the_value(); ?>"/>
		</div>
</div>

